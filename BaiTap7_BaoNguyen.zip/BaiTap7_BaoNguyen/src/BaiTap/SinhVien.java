package BaiTap;

import java.util.Scanner;

public class SinhVien {
private int maSv;
private String hoTen;
private float diemLT;
private float diemTH;
// hàm tạo mặc định
public SinhVien() {
	super();
}
// hàm tạo có tham số
public SinhVien(int maSv, String hoTen, float diemLT, float diemTH) {
	super();
	this.maSv = maSv;
	this.hoTen = hoTen;
	this.diemLT = diemLT;
	this.diemTH = diemTH;
}

// getter và setter
public int getMaSv() {
	return maSv;
}
public void setMaSv(int maSv) {
	this.maSv = maSv;
}
public String getHoTen() {
	return hoTen;
}
public void setHoTen(String hoTen) {
	this.hoTen = hoTen;
}
public float getDiemLT() {
	return diemLT;
}
public void setDiemLT(float diemLT) {
	this.diemLT = diemLT;
}
public float getDiemTH() {
	return diemTH;
}
public void setDiemTH(float diemTH) {
	this.diemTH = diemTH;
}

// tính điểm trung bình
public float getDiemTB() {
	return (this.diemLT+this.diemTH)/2;
}

// xuất thông tin
public String toString() {
	return "Ma sinh vien: " + this.maSv + "\n" + "Ho ten sinh vien: " + this.hoTen + "\n" + "diem LT: " + this.diemLT + "\n"
			+ "diem TH: " + this.diemTH + "\n" + "diem trung binh: " + this.getDiemTB();
}

public static void main(String[] args) {
	Scanner sc = new Scanner (System.in);
	SinhVien sv1 = new SinhVien(1, "Bao", 10, 8);
	System.out.println("thong tin sv: "+ sv1.toString());
	SinhVien sv2 = new SinhVien(2, "Van", 10, 10);
	SinhVien sv3 = new SinhVien();
	System.out.println("nhap ten sv3: ");
	sv3.setHoTen(sc.nextLine());
	System.out.println("nhap mssv sv3: ");
	sv3.setMaSv(sc.nextInt());
	System.out.println("nhap diem lt sv3: ");
	sv3.setDiemLT(sc.nextFloat());
	System.out.println("nhap diem th sv3: ");
	sv3.setDiemTH(sc.nextFloat());
	System.out.println("thong tin sv3: "+ sv3.toString());
}
}
