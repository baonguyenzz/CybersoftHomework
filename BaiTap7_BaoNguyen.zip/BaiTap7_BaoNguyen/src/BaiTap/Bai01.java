package BaiTap;

public class Bai01 { // bài 2 tương tự bài 1
	private float a, b, c;

// hàm tạo ko tham số
	public Bai01() {
		super();
	}

// hàm tạo 3 tham số
	public Bai01(float a, float b, float c) {
		super();
		this.a = a;
		this.b = b;
		this.c = c;
	}

// getter and setter
	public float getA() {
		return a;
	}

	public void setA(float a) {
		this.a = a;
	}

	public float getB() {
		return b;
	}

	public void setB(float b) {
		this.b = b;
	}

	public float getC() {
		return c;
	}

	public void setC(float c) {
		this.c = c;
	}

// phương thức tính delta
	public float getDelta() {
		return (b * b - 4 * a * c);
	}

// phương thức tính nghiệm phương trình
	public void getNghiem() {
		if (this.a == 0) { // pt bậc 1
			if (this.b == 0) {
				if (this.c == 0)
					System.out.println("pt co vo so nghiem");
				else
					System.out.println("pt vo nghiem");
			} else
				System.out.println("pt co nghiem duy nhat: x = " + (-this.c / this.b));
		} else if (this.getDelta() < 0)
			System.out.println("pt vo nghiem");
		  else if (this.getDelta() == 0)
			System.out.println("pt co nghiem kep x1 = x2 = " + (-this.b / (2 * this.a)));
		  else
			System.out.println("pt co 2 nghiem phan biet x1 = " + (-this.b - Math.sqrt(getDelta())) / (2 * this.a)
					+ " x2 = " + (-this.b + Math.sqrt(getDelta())) / (2 * this.a));
	}
	public static void main(String[] args) {
		Bai01 b1 = new Bai01(3, 5, 2);
		b1.getNghiem();
	}
}
