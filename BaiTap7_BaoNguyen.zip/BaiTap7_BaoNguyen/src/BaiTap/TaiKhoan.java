package BaiTap;

import java.util.Scanner;

public class TaiKhoan {
	private long soTK;
	private String tenTK;
	private double soTien;
	private final float laiSuat = (float) 0.035;
	private final float phiRutTien = (float) 1;

//hàm tạo mặc định
	public TaiKhoan() {
		super();
	}

// hàm tạo 2 tham số với số tiền ban đầu trong tài khoản là 50$
	public TaiKhoan(long soTK, String tenTK) {
		super();
		this.soTK = soTK;
		this.tenTK = tenTK;
		this.soTien = 50;
	}

//hàm tạo có tham số
	public TaiKhoan(long soTK, String tenTK, double soTien) {
		super();
		this.soTK = soTK;
		this.tenTK = tenTK;
		this.soTien = soTien;
	}

//getter và setter
	public long getSoTK() {
		return soTK;
	}

	public void setSoTK(long soTK) {
		this.soTK = soTK;
	}

	public String getTenTK() {
		return tenTK;
	}

	public void setTenTK(String tenTK) {
		this.tenTK = tenTK;
	}

	public double getSoTien() {
		return soTien;
	}

	public void setSoTien(double soTien) {
		this.soTien = soTien;
	}

	public String toString() {
		return "So tai khoan: " + this.soTK + "\n" + "Ten tai khoan: " + this.tenTK + "\n" + "So tien trong tai khoan: "
				+ this.soTien + "$" + "\n";
	}

// nạp tiền
	public void napTien() {
		Scanner sc = new Scanner(System.in);
		double tienNap;
		System.out.println("Moi nhap so tien muon nap vao tai khoan: ");
		do {
			tienNap = sc.nextDouble();
			if (tienNap < 0)
				System.out.println("So tien khong hop le, vui long nhap lai");
		} while (tienNap < 0);
		this.setSoTien(this.soTien + tienNap);
		System.out.println("thong tin tai khoan: " + this.toString());
	}

//rút tiền
	public void rutTien() {
		Scanner sc = new Scanner(System.in);
		double tienRut;
		System.out.println("Moi nhap so tien muon rut: ");
		do {
			tienRut = sc.nextDouble();
			if (tienRut > this.soTien)
				System.out.println("Tai khoan khong du de thuc hien giao dich nay!");
		} while (tienRut > this.soTien);
		this.setSoTien(this.soTien - (tienRut + this.phiRutTien));
		System.out.println("Rut tien thanh cong" + this.toString());

	}

//đáo hạn
	public double daoHan() {
		return this.soTien = (this.soTien + this.soTien * this.laiSuat);
	}

//chuyển khoản
	public void chuyenKhoan() {
		Scanner sc = new Scanner(System.in);
		double chuyenTien;
		System.out.println("Moi nhap so tien muon chuyen: ");
		do {
			chuyenTien = sc.nextDouble();
			if (chuyenTien > this.soTien)
				System.out.println("Tai khoan khong du de thuc hien giao dich nay! Moi nhap lai");
		} while (chuyenTien > this.soTien);
		this.setSoTien(this.soTien - chuyenTien);
		System.out.println("Chuyen tien thanh cong" + this.toString());

	}

	public static void main(String[] args) {
		TaiKhoan tk = new TaiKhoan(1, "Bao");
		tk.napTien();
		tk.rutTien();
		tk.daoHan();
		System.out.println("thong tin tai khoan sau khi dao han: " + tk.toString());
		tk.chuyenKhoan();
	}
}
