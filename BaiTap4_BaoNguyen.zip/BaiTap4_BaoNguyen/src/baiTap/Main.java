package baiTap;

import java.util.Scanner;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.time.LocalDate;

public class Main {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int n;
		do {
			System.out.println("Moi nhap so phan tu cua mang: ");
			n = sc.nextInt();
		} while (n < 0);
		int array[] = new int[n]; // tạo và cấp phát bộ nhớ cho mảng
		System.out.println("Nhap tung phan tu cua mang: ");
		for (int i = 0; i < n; i++) {
			array[i] = sc.nextInt();
		} // duyet mang va nhap phan tu mang
		System.out.println("Mang ban dau:");
		for (int i = 0; i < n; i++) {
			System.out.print(array[i] + "\t");
		} // xuat mang ra man hinh
		int so; // câu a
		do {
			System.out.printf("|Y1. Tong so duong\n");
			System.out.printf("|Y2. Tong so le\n");
			System.out.printf("|Y3. Dem co bao nhieu so duong\n");
			System.out.printf("|Y4. Tim so nho nhat trong mang\n");
			System.out.printf("|Y5. Tim so duong nho nhat trong mang\n");
			System.out.printf("|Y6. Tim so chan cuoi cung trong mang. Neu ko co tra ve gia tri -1\n");
			System.out.printf("|Y7. Tim so chan dau tien trong mang. Neu ko co tra ve gia tri -1\n");
			System.out.printf("|Y8. Tim so nguyen to dau tien trong mang. Neu ko co tra ve gia tri -1\n");
			System.out.printf("|Y9. Tim so duong cuoi cung trong mang. Neu ko co tra ve gia tri -1\n");
			System.out.printf("|Y10. Tim gia tri chan nho nhat trong mang. Neu ko co tra ve gia tri -1\n");
			System.out.print("Moi nhap chuc nang: ");
			so = sc.nextInt();
			switch (so) {
			case 1:
				System.out.printf("\nChao mung ban den voi chuc nang so 1: Tong so duong\n");
				tongSoDuong(array);
				break;
			case 2:
				System.out.printf("\nChao mung ban den voi chuc nang so 2: Tong so le\n");
				tongSoLe(array);
				break;
			case 3:
				System.out.printf("\nChao mung ban den voi chuc nang so 3: Dem co bao nhieu so duong\n");
				demSoDuong(array);
				break;
			case 4:
				System.out.printf("\nChao mung ban den voi chuc nang so 4: Tim so nho nhat trong mang\n");
				findMin(array);
				break;
			case 5:
				System.out.printf("\nChao mung ban den voi chuc nang so 5: Tim so duong nho nhat trong mang\n");
				findMinPos(array);
				break;
			case 6:
				System.out.printf(
						"\nChao mung ban den voi chuc nang so 6: Tim so chan cuoi cung trong mang. Neu ko co tra ve gia tri -1\n");
				findLastEvenNum(array);
				break;
			case 7:
				System.out.printf(
						"\nChao mung ban den voi chuc nang so 7: Tim so chan dau tien trong mang. Neu ko co tra ve gia tri -1\n");
				findFirstEvenNum(array);
				break;
			case 8:
				System.out.printf(
						"\nChao mung ban den voi chuc nang so 8: Tim so nguyen to dau tien trong mang. Neu ko co tra ve gia tri -1\n");
				findFirstPrime(array);
				break;
			case 9:
				System.out.printf(
						"\nChao mung ban den voi chuc nang so 9: Tim so duong cuoi cung trong mang. Neu ko co tra ve gia tri -1\n");
				findlastPos(array);
				break;
			case 10:
				System.out.printf(
						"\nChao mung ban den voi chuc nang so 10: Tim gia tri chan nho nhat trong mang. Neu ko co tra ve gia tri -1\n");
				findMinEvenNum(array);
				break;
			case 11:
				break;
			}
		} while (so != 11);
	} // end main
		// tổng số dương (câu b)

	public static void tongSoDuong(int[] array) {
		int tong = 0;
		for (int i = 0; i < array.length; i++) {
			if (array[i] > 0) {
				tong += array[i];
			}
		}
		System.out.println("Tong cac so duong la: " + tong + "\n");
	}

	// tổng số lẻ (câu c)
	public static void tongSoLe(int[] array) {
		int tong = 0;
		for (int i = 0; i < array.length; i++) {
			if (!(array[i] % 2 == 0)) {
				tong += array[i];
			}
		}
		System.out.println("Tong cac so le la: " + tong + "\n");
	}

	// đếm số lượng số dương (câu d)
	public static void demSoDuong(int[] array) {
		int count = 0;
		for (int i = 0; i < array.length; i++) {
			if (array[i] > 0) {
				count++;
			}
		}
		System.out.println("So luong so duong co trong mang la: " + count + "\n");
	}

	// tìm số nhỏ nhất trong mảng (câu e)
	public static void findMin(int[] array) {
		int[] copyArray = Arrays.copyOf(array, array.length); // copy mảng ban đầu để cuối hàm khôi phục lại dùng cho
																// câu khác
		Arrays.sort(array);
		System.out.println("\nGia tri nho nhat cua mang la:" + array[0] + "\n");
		System.arraycopy(copyArray, 0, array, 0, copyArray.length); // khôi phục lại mảng
	}

	// tìm số dương nhỏ nhất trong mảng (câu f)
	public static void findMinPos(int[] array) {
		int[] copyArray = Arrays.copyOf(array, array.length); // copy mảng ban đầu để cuối hàm khôi phục lại dùng cho
																// câu khác
		int minPos = -1;
		Arrays.sort(array);
		for (int i = 0; i < array.length; i++) {
			if (array[i] > 0) {
				minPos = array[i];
				System.out.println("\nGia tri duong nho nhat cua mang la:" + minPos + "\n");
				System.arraycopy(copyArray, 0, array, 0, copyArray.length); // khôi phục lại mảng
				return;
			}
		}
		System.out.println("Khong co phan tu duong trong mang: " + minPos);
		System.arraycopy(copyArray, 0, array, 0, copyArray.length); // khôi phục lại mảng
	}

	// tìm số chẵn cuối cùng trong mảng (câu g)
	public static void findLastEvenNum(int[] array) {
		int[] copyArray = Arrays.copyOf(array, array.length); // copy mảng ban đầu để cuối hàm khôi phục lại dùng cho
																// câu khác
		int lastEvenNum = -1;
		// gán giá trị lastEvenNum cho phần tử chẵn cuối cùng trong mảng
		for (int i = 0; i < array.length; i++) {
			if (array[i] % 2 == 0) {
				lastEvenNum = array[i];
			}
		}
		// đảo ngược mảng
		int temp;
		int left = 0;
		int right = array.length - 1;
		while (left < right) {
			temp = array[left];
			array[left] = array[right];
			array[right] = temp;
			left++;
			right--;
		}
		// duyệt mảng đến khi có phần tử đầu tiên bằng với lastEvenNum thì dừng
		for (int i = 0; i < array.length; i++) {
			if (array[i] == lastEvenNum) {
				System.out.println("So chan cuoi cung cua mang ban dau la: " + lastEvenNum + "\n");
				System.arraycopy(copyArray, 0, array, 0, copyArray.length);
				return;
			}
		}
		System.out.println("Khong co phan tu chan trong mang: " + lastEvenNum);
		System.arraycopy(copyArray, 0, array, 0, copyArray.length); // khôi phục lại mảng
	}

	// tìm số chẵn đầu tiên trong mảng (câu h)
	public static void findFirstEvenNum(int[] array) {
		int firstEvenNum = -1;
		// gán giá trị firstEvenNum cho phần tử chẵn đầu tiên tìm thấy
		for (int i = 0; i < array.length; i++) {
			if (array[i] % 2 == 0) {
				firstEvenNum = array[i];
				System.out.println("So chan dau tien cua mang la: " + firstEvenNum + "\n");
				return;
			}
		}
		System.out.println("Khong co phan tu chan trong mang: " + firstEvenNum);
	}

	// tìm số nguyên tố đầu tiên trong mảng (câu i)
	public static void findFirstPrime(int[] array) {
		int FirstPrime = -1;
		for (int i = 0; i < array.length; i++) {
			if (array[i] <= 1) {
				break;
			}
			for (int j = 2; j < array[i]; j++) {
				if (array[i] % j == 0) {
					break;
				} else {
					FirstPrime = array[i];
					System.out.println("So nguyen to dau tien trong mang la: " + FirstPrime);
					return;
				}
			}
		}
		System.out.println("Khong co so nguyen to trong mang: " + FirstPrime);
	}

	// tìm số dương cuối cùng trong mảng (câu j)
	public static void findlastPos(int[] array) {
		int[] copyArray = Arrays.copyOf(array, array.length); // copy mảng ban đầu để cuối hàm khôi phục lại dùng cho
																// câu khác
		int lastPos = -1;
		// gán giá trị lastPos cho phần tử dương cuối cùng trong mảng
		for (int i = 0; i < array.length; i++) {
			if (array[i] > 0) {
				lastPos = array[i];
			}
		}
		// đảo ngược mảng
		int temp;
		int left = 0;
		int right = array.length - 1;
		while (left < right) {
			temp = array[left];
			array[left] = array[right];
			array[right] = temp;
			left++;
			right--;
		}
		// duyệt lại mảng đến khi có phần tử đầu tiên bằng với lastPos thì dừng
		for (int i = 0; i < array.length; i++) {
			if (array[i] == lastPos) {
				System.out.println("So duong cuoi cung cua mang ban dau la: " + lastPos + "\n");
				System.arraycopy(copyArray, 0, array, 0, copyArray.length); // khôi phục lại mảng
				return;
			}
		}
		System.out.println("Khong co phan tu duong trong mang: " + lastPos);
		System.arraycopy(copyArray, 0, array, 0, copyArray.length); // khôi phục lại mảng
	}

	// tìm số chẵn nhỏ nhất trong mảng (câu k)
	public static void findMinEvenNum(int[] array) {
		int[] copyArray = Arrays.copyOf(array, array.length); // copy mảng ban đầu để cuối hàm khôi phục lại dùng cho
																// câu khác
		int minEvenNum = -1;
		Arrays.sort(array);
		for (int i = 0; i < array.length; i++) {
			if (array[i] % 2 == 0) {
				minEvenNum = array[i];
				System.out.println("\nGia tri chan nho nhat cua mang la:" + minEvenNum + "\n");
				System.arraycopy(copyArray, 0, array, 0, copyArray.length); // khôi phục lại mảng
				return;
			}
		}
		System.out.println("Khong co phan tu chan trong mang: " + minEvenNum);
		System.arraycopy(copyArray, 0, array, 0, copyArray.length); // khôi phục lại mảng
	}

}
