package buoi2cyber;

public class demobuoi2 {
	public static void main(String[] args) {
		//Tính tổng 2 số A và B. Nếu tổng của 2 số mà lớn hơn 15
		// và hiệu lớn hơn 5 thì cộng thêm cho 5
		// ngược lại thì giữ nguyên tổng
		// các phép so sánh: < , <=, >=, == , !=
		//&&(và): Kết quả trả ra là true khi các điều kiện thỏa
		// || (hoặc): Kết quả trả ra là true khi một trong các điều kiện
		// thỏa
		// true && true >= true
		// true && false >= false
		int soA = 5;
		int soB = 10;
		int tong = soA + soB;
		if (tong> 15) {
			// code chạy khi thỏa điều kiện if. Kết quả của biểu thức 
			// so sánh bên trong if là true thì mới chạy
			tong += 5; // tong += 5 <=> tong = tong + 5
			// tong -= 5 <=> tong = tong * 5
			System.out.println("Giá trị của tổng bên trong if "+ tong);
		}else {
			//code chạy khi không thỏa điều kiện if
			System.out.println("Giá trị của tổng ko thỏa if "+ tong);
		}
		// so sánh 3 ngôi
		// Chỉ sử dụng khi điều kiện so sánh trả ra giá trị mới. Không
		// xử lý logic code.
		// Điều kiện so sánh ? thỏa điều kiện : không thỏa điều kiện
		tong = tong > 15 ? tong + 5: tong;
		
	}

}
