package buoi2cyber;

import java.util.Scanner;

public class buoi2baitap {
public static void tinhcanhhuyen() {
	float canha,canhb;
	float canhhuyen;
	Scanner sc = new Scanner (System.in);
	System.out.println("moi nhap canh a:");
	canha = sc.nextFloat();
	System.out.println("moi nhap canh b:");
	canhb = sc.nextFloat();
	System.out.println("canh huyen la:" + Math.sqrt(((canha*canha)+(canhb*canhb))));
}
public static void tinhtrungbinh() {
	int[] a = new int[5];
	for (int i = 0; i < 5; i++) {
		Scanner sc = new Scanner (System.in);
		System.out.println("Moi nhap phan tu mang thu" + (i+1));
		a[i] = sc.nextInt();
	}
	int tong = 0, count=0;
	for (int i = 0; i < 5; i++) {
		 tong += a[i];
		 count++;
	}	
	System.out.println("tong cac so trong mang: " +tong );
	System.out.println("Trung binh 5 so nhap tu ban phim la: "+ tong/count);   
}
public static void tinhdoF() {
	Scanner sc = new Scanner (System.in);
	float doC,doF;
	System.out.println("moi nhap do C: ");
	doC = sc.nextFloat();
	System.out.println("Do F la:" + (doC*1.8+32));
}
public static void tinhVND() {
	Scanner sc = new Scanner (System.in);
	float vnd,usd;
	System.out.println("moi nhap do usd: ");
	usd = sc.nextFloat();
	System.out.println("vnd:" + (usd*23500));
}
public static void tinhtong2kyso() {
	Scanner sc = new Scanner (System.in);
	int a;
	System.out.println("moi nhap so nguyen duong 2 ky tu: ");
	a = sc.nextInt();
	System.out.println("tong 2 ky so cua a: "+ (a/10 +a%10));
}
public static void xepLoai() {
	String ten;
	float toan,ly,hoa,diemTB;
	do {
	Scanner sc = new Scanner (System.in);
	System.out.println("Moi nhap ho ten");
	ten = sc.nextLine();
	System.out.println("Moi nhap diem toan: ");
	toan = sc.nextFloat();
	System.out.println("Moi nhap diem ly: ");
	ly = sc.nextFloat();
	System.out.println("Moi nhap diem hoa: ");
	hoa = sc.nextFloat();
	diemTB = (toan+ly+hoa)/3;
	} while((0>toan || toan>10) || (0>ly || ly>10) || (0>hoa || hoa>10));
	if(diemTB>8.5) {
		System.out.println("Diem trung binh la:" +diemTB);
		System.out.println("Gioi");
	}
	if(diemTB>=6.5 && diemTB <8.5) {
		System.out.println("Diem trung binh la:" +diemTB);
		System.out.println("Kha");
	}
	if(diemTB>=5 && diemTB <6.5) {
		System.out.println("Diem trung binh la:" +diemTB);
		System.out.println("Trung Binh");
	}
	if(diemTB<5) {
		System.out.println("Diem trung binh la:" +diemTB);
		System.out.println("Yeu");
	}
	
}
public static void main(String[] args) {
	
	xepLoai();
	
}
}
