package baiTap;

import java.util.Scanner;

public class Main {
	// bài 1
	public static void bai1() {
		Scanner sc = new Scanner(System.in);
		System.out.println("Moi ban nhap vao mot so: ");
		int a = sc.nextInt(); // nhập một số từ bàn phím
		if (a % 5 == 0) { // xét điều kiện thỏa a chia lấy dư cho 5 có bằng 0 ?
			System.out.println("So " + a + " chia het cho 5!");
		} else {
			System.out.println("So " + a + " ko chia het cho 5!");
		}

	}

// bài 2
	public static void bai2() {
		String ten, mssv, gioitinh;
		int tuoi;
		// lay du lieu tu ban phim
		Scanner sc = new Scanner(System.in);
		do {
			System.out.println("Moi nhap ho ten: ");
			ten = sc.nextLine();
		} while (ten.equalsIgnoreCase("")); // check hợp lệ ko để trống
		do {
			System.out.println("Moi nhap tuoi: ");
			tuoi = sc.nextInt();
		} while (!(tuoi > 0)); // check tuổi ko âm
		do {
			System.out.println("Moi nhap gioi tinh: ");
			gioitinh = sc.nextLine();
		} while (!gioitinh.equalsIgnoreCase("Nam") && !gioitinh.equalsIgnoreCase("Nu")); // check hợp lệ chỉ nam or nữ
		do {
			System.out.println("Moi nhap mssv: ");
			mssv = sc.nextLine();
		} while (mssv.equalsIgnoreCase("")); // check hợp lệ ko để trống
		// in ra màn hình
		System.out.println("Thong tin sinh vien: " + ten + "\n" + tuoi + "\n" + gioitinh + "\n" + mssv);
	}

// bài 3
	public static void bai3() {
		Scanner sc = new Scanner(System.in);
		int a, b;
		System.out.println("moi nhap so a: ");
		a = sc.nextInt();
		System.out.println("moi nhap so b: ");
		b = sc.nextInt();
		System.out.println("Tong 2 so la: " + (a + b));
	}

// bài 4
	public static void bai4() {
		Scanner sc = new Scanner(System.in);
		int n;
		System.out.println("moi nhap so n: ");
		n = sc.nextInt();
		if (n % 2 == 0) // check n chia lấy dư 2 có bằng 0 ?
			System.out.println(n + " la so chan");
		else
			System.out.println(n + " la so le");
	}

//bài 5
	public static void bai5() {
		Scanner sc = new Scanner(System.in);
		System.out.println("moi chon con vat: ");
		String animal = sc.nextLine();
		switch (animal) {
		case "cho":
			System.out.println("gau gau");
			break;
		case "meo":
			System.out.println("meow meow");
			break;
		case "heo":
			System.out.println("un in ");
			break;
		case "ga":
			System.out.println("cuc tac");
			break;
		default:
			System.out.println("ko xac dinh");
			break;
		}
	}

// bài 6
	public static void bai6() {
		Scanner sc = new Scanner(System.in);
		System.out.println("moi nhap tham so bac 1: ");
		float a = sc.nextFloat();
		System.out.println("moi nhap tham so tu do: ");
		float b = sc.nextFloat();
		if (a == 0) {
			if (b == 0)
				System.out.println("pt co vo so nghiem");
			else
				System.out.println("pt vo nghiem");
		} else
			System.out.println(" pt co nghiem duy nhat: " + -b / a);
	}

// bài 7
	public static void bai7() {
		Scanner sc = new Scanner(System.in);
		System.out.println("moi nhap tham so bac 2: ");
		float a = sc.nextFloat();
		System.out.println("moi nhap tham so bac 1: ");
		float b = sc.nextFloat();
		System.out.println("moi nhap tham so tu do: ");
		float c = sc.nextFloat();
		// Tính delta
		float delta = b * b - 4 * a * c;
		if (a == 0) {
			if (b == 0) {
				if (c == 0)
					System.out.println("pt co vo so nghiem");
				else
					System.out.println("pt vo nghiem");
			} else
				System.out.println(" pt co nghiem duy nhat: " + -c / b);
		}
		// Kiểm tra giá trị của delta để xác định nghiệm
		if (delta > 0) {
			float x1 = (float) ((-b + Math.sqrt(delta)) / (2 * a));
			float x2 = (float) ((-b - Math.sqrt(delta)) / (2 * a));
			System.out.println("pt co 2 nghiem phan biet:");
			System.out.println("x1 = " + x1);
			System.out.println("x2 = " + x2);
		} else if (delta == 0) {
			float x = -b / (2 * a);
			System.out.println("pt co nghiem kep:");
			System.out.println("x = " + x);
		} else {
			System.out.println("Phương trình vô nghiệm.");
		}

	}

	public static void main(String[] args) {
		bai7();
	}
}
