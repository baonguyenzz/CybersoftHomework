package BaiTap;

import java.util.Scanner;

public class SinhVien {
public String hoTen;
public String maSV;
public double toan;
public double ly;
public double hoa;
public SinhVien() {
	super();
}
public SinhVien(String hoTen, String maSV, double toan, double ly, double hoa) {
	super();
	this.hoTen = hoTen;
	this.maSV = maSV;
	this.toan = toan;
	this.ly = ly;
	this.hoa = hoa;
}
public String getHoTen() {
	return hoTen;
}
public void setHoTen(String hoTen) {
	this.hoTen = hoTen;
}
public String getMaSV() {
	return maSV;
}
public void setMaSV(String maSV) {
	this.maSV = maSV;
}
public double getToan() {
	return toan;
}
public void setToan(double toan) {
	this.toan = toan;
}
public double getLy() {
	return ly;
}
public void setLy(double ly) {
	this.ly = ly;
}
public double getHoa() {
	return hoa;
}
public void setHoa(double hoa) {
	this.hoa = hoa;
}

public double trungBinh() {
	return (this.toan + this.ly + this.hoa)/3;
}
public String getXepLoai() {
	if(trungBinh()>=9) {
		return "Xuat Sac";
	} else if(trungBinh()>=8) {
		return "Gioi";
	} else if(trungBinh()>=8) {
		return "Kha";
	} else if(trungBinh()>=8) {
		return "Trung Binh";
	} else {
		return "Yeu";
	}
}
public void nhap() {
	Scanner sc = new Scanner (System.in);
	System.out.println("Moi nhap ten sv: ");
	this.hoTen = sc.nextLine();
	System.out.println("Moi nhap ma so sv: ");
	this.maSV = sc.nextLine();
	System.out.println("Moi nhap diem mon toan: ");
	this.toan = sc.nextDouble();
	System.out.println("Moi nhap diem mon ly: ");
	this.ly = sc.nextDouble();
	System.out.println("Moi nhap diem mon hoa: ");
	this.hoa = sc.nextDouble();
}
public void xuat () {
	System.out.printf("\n%s\t\t\t%s\t\t\t%.2f\t\t\t%.2f\t\t\t%.2f\t\t\t%.2f\t\t\t%s",this.maSV,this.hoTen,this.toan,this.ly,this.hoa,trungBinh(),getXepLoai());
}

}
