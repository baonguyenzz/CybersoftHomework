package BaiTap;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Scanner;

public class Main {
	public static ArrayList <SinhVien> list = new ArrayList<>();
	public static int n;
	public static Scanner sc = new Scanner(System.in);
public static void main(String[] args) {
	Scanner sc = new Scanner(System.in);
	// khai báo kích thước mảng sv cần nhập
	System.out.println("Nhap so luong sinh vien: ");
	 n = sc.nextInt();
	 // add sv vào mảng
	for (int i = 0; i < n; i++) {
		SinhVien sv = new SinhVien();
		sv.nhap();
		list.add(sv);
	}
	
	findSVByName();
}
// bài 1
public static void bai1() {
	System.out.println("Moi nhap ten sinh vien");
	String ten = sc.nextLine();
	System.out.println("Moi nhap ma sinh vien");
	String maSv = sc.nextLine();
	System.out.println("Moi nhap diem mon toan: ");
	double toan = sc.nextDouble();
	System.out.println("Moi nhap diem mon ly: ");
	double ly = sc.nextDouble();
	System.out.println("Moi nhap diem mon hoa: ");
	double hoa = sc.nextDouble();
	double trungBinh = (toan+ly+hoa)/3;
	if(trungBinh>=9) {
		System.out.printf("Sinh vien %s \nMa: %s \nXep loai: Xuat sac %.2f ", ten, maSv, trungBinh);
	} else if(trungBinh >=8) {
		System.out.printf("Sinh vien %s \nMa: %s \nXep loai: Gioi %.2f" , ten, maSv, trungBinh);
	} else if(trungBinh>=7) {
		System.out.printf("Sinh vien %s \nMa: %s \nXep loai: Kha %.2f" , ten, maSv, trungBinh);
	} else if(trungBinh>=6) {
		System.out.printf("Sinh vien %s \nMa: %s \nXep loai: Trung Binh %.2f" , ten, maSv, trungBinh);
	} else {
		System.out.printf("Sinh vien %s \nMa: %s \nXep loai: Yeu %.2f", ten, maSv,trungBinh);
	}
}
// xuất danh sách sv
public static void xuatDanhSachSV() {
	System.out.println("Ma SV\t\t\tHo ten\t\t\tToan\t\t\tLy\t\t\tHoa\t\t\tTrung Binh\t\tXep Loai"); // tạo dòng tiêu đề
	// duyệt mảng sv đã nhập vào list
	for (SinhVien sv : list) {
		sv.xuat();
	}
}
// xuất danh sách sv điểm tb cao nhất
public static void maxDiemTB() {
	double maxTB = list.get(0).trungBinh(); // gán giá trị max cho phần tử đầu tiên của mảng sv
	for (SinhVien sv : list) {
		if(sv.trungBinh()>maxTB) {
			maxTB = sv.trungBinh();
		}
	} // tìm ra giá trị điểm trung bình max
	ArrayList <SinhVien> maxTBlist = new ArrayList<>(); // tạo mảng mới chứa danh sách những sinh viên có cùng điểm tb max
	for (SinhVien sv : list) {
		if(sv.trungBinh() == maxTB) {
			maxTBlist.add(sv);
		}
	} // add vào mảng
	System.out.println("Danh sach nhung sinh vien co diem trung binh cao nhat");
	System.out.println("Ma SV\t\t\tHo ten\t\t\tToan\t\t\tLy\t\t\tHoa\t\t\tTrung Binh\t\tXep Loai"); // tạo dòng tiêu đề
	for (SinhVien sv : maxTBlist) {
		sv.xuat();
	}
}
// xuất danh sách sv yếu
public static void svYeu() {
	System.out.println("Danh sach nhung sinh vien co diem trung binh yeu");
	System.out.println("Ma SV\t\t\tHo ten\t\t\tToan\t\t\tLy\t\t\tHoa\t\t\tTrung Binh\t\tXep Loai"); // tạo dòng tiêu đề
	for (SinhVien sv : list) { // duyệt mảng so sánh thuộc tính getXepLoai của đối tượng sinh viên với chữ Yếu
		if(sv.getXepLoai().equalsIgnoreCase("Yeu")) {
			sv.xuat();
		}
	}

}
// Xuất danh sách sinh viên theo tên
public static void findSVByName() {
	System.out.println("Moi nhap ten sinh vien can tim: ");
	String name = sc.nextLine();
	System.out.println("Danh sach nhung sinh vien co ten can tim");
	System.out.println("Ma SV\t\t\tHo ten\t\t\tToan\t\t\tLy\t\t\tHoa\t\t\tTrung Binh\t\tXep Loai"); // tạo dòng tiêu đề
	for (SinhVien sv : list) {// duyệt mảng so sánh thuộc tính họ tên của đối tượng sinh viên với tên vừa nhập vào
		if(sv.hoTen.equalsIgnoreCase(name)) {
			sv.xuat();
		}
	}
}
// Tìm sv theo ID
public static void findSVByID() {
	System.out.println("Moi nhap ma sinh vien can tim: ");
	String ID = sc.nextLine();
	System.out.println("Sinh vien co ma can tim");
	System.out.println("Ma SV\t\t\tHo ten\t\t\tToan\t\t\tLy\t\t\tHoa\t\t\tTrung Binh\t\tXep Loai"); // tạo dòng tiêu đề
	for (SinhVien sv : list) { // duyệt mảng so sánh thuộc tính mã sv của đối tượng sinh viên với ID vừa nhập vào
		if(sv.maSV.equalsIgnoreCase(ID)) {
			sv.xuat();
		}
	}
}
// Xóa sv theo ID
public static void delSVByID() {
	System.out.println("Moi nhap ma sinh vien can xoa: ");
	String ID = sc.nextLine();
	for (SinhVien sv : list) {
		if(sv.maSV.equalsIgnoreCase(ID)) {
			list.remove(sv); // xóa phần tử sv có thuộc tính thỏa điều kiện trên khỏi list
		}
	}
	System.out.println("Xoa thanh cong");
	xuatDanhSachSV(); // gọi lại danh sách hiển thị cho ng dùng xem đã cập nhật
}
}
