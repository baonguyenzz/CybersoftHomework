package baiTap;

public class SinhVien {
	private String tenSV;
	private ToaDo toaDoSV;

	public SinhVien() {
		super();
	}

	public SinhVien(String tenSV, ToaDo toaDoSV) {
		super();
		this.tenSV = tenSV;
		this.toaDoSV = toaDoSV;
	}

	public String getTenSV() {
		return tenSV;
	}

	public void setTenSV(String tenSV) {
		this.tenSV = tenSV;
	}

	public ToaDo getToaDoSV() {
		return toaDoSV;
	}

	public void setToaDoSV(ToaDo toaDoSV) {
		this.toaDoSV = toaDoSV;
	}

}
