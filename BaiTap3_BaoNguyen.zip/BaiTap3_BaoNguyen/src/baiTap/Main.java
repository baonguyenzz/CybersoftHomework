package baiTap;

import java.util.Scanner;
import java.util.ArrayList;
import java.util.Iterator;
import java.time.LocalDate;

public class Main {
	// bài 1
	public static void bai1() {
		Scanner sc = new Scanner(System.in);
		System.out.println("Moi ban nhap vao so a: ");
		int a = sc.nextInt(); // nhập một số từ bàn phím
		System.out.println("Moi ban nhap vao so b: ");
		int b = sc.nextInt(); // nhập một số từ bàn phím
		System.out.println("Moi ban nhap vao so c: ");
		int c = sc.nextInt(); // nhập một số từ bàn phím
		int max = a; // gán giá trị max cho a
		if (max < b) {
			max = b;
		}
		if (max < c) {
			max = c;
		}
		System.out.println("So lon nhat trong 3 so vua nhap la: " + max);

	}

// bài 2
	public static void bai2() {
		Scanner sc = new Scanner(System.in);
		System.out.println("Moi ban nhap vao so n: ");
		int n = sc.nextInt(); // nhập một số từ bàn phím
		if (n % 2 == 0) {
			System.out.println(n + " " + "la so chan");
		} else {
			System.out.println(n + " " + "la so le");
		}
	}

// bài 3
	public static void bai3() {
		Scanner sc = new Scanner(System.in);
		System.out.println("Moi ban nhap vao so a: ");
		int a = sc.nextInt(); // nhập một số từ bàn phím
		System.out.println("Moi ban nhap vao so b: ");
		int b = sc.nextInt(); // nhập một số từ bàn phím
		System.out.println("Moi ban nhap vao so c: ");
		int c = sc.nextInt(); // nhập một số từ bàn phím
		System.out.println("Tong 3 so vua nhap vao la: " + (a + b + c));
	}

// bài 4
	public static void bai4() {
		do {
			Scanner sc = new Scanner(System.in);
			System.out.println("Moi nhap so a: ");
			int a = sc.nextInt();
			System.out.println("Moi nhap so b: ");
			int b = sc.nextInt();
			System.out.println("Moi chon phep toan: ");
			String dau = sc.nextLine();
			switch (dau) {
			case "+":
				System.out.println("Tong la: " + (a + b));
				break;
			case "-":
				System.out.println("Hieu la: " + (a - b));
				break;
			case "*":
				System.out.println("Tich la: " + (a * b));
				break;
			case "/":
				System.out.println("Thuong la: " + (a / b));
				break;
			default:
				System.out.println("Error");
			}
		} while (true);
	}

//bài 5
	public static void bai5() {
		Scanner sc = new Scanner(System.in);
		System.out.println("Nhap ten sinh vien A: ");
		String tenA = sc.nextLine();
		System.out.println("Nhap nam sinh sinh vien A");
		int namSinhA = sc.nextInt();
		System.out.println("Nhap ten sinh vien B: ");
		String tenB = sc.nextLine();
		System.out.println("Nhap nam sinh sinh vien B");
		int namSinhB = sc.nextInt();
		System.out.println("Nhap ten sinh vien C: ");
		String tenC = sc.nextLine();
		System.out.println("Nhap nam sinh sinh vien C");
		int namSinhC = sc.nextInt();
		int treNhat = LocalDate.now().getYear() - namSinhA;
		String svTreNhat = tenA;
		if ((LocalDate.now().getYear() - namSinhB) < treNhat) {
			treNhat = LocalDate.now().getYear() - namSinhB;
			svTreNhat = tenB;
		}
		if ((LocalDate.now().getYear() - namSinhC) < treNhat) {
			treNhat = LocalDate.now().getYear() - namSinhC;
			svTreNhat = tenC;
		}
		System.out.println("Sinh vien tre nhat la: " + svTreNhat);
		System.out.println("Tuoi: " + treNhat);
	}

// bài 6
	public static void bai6() {
		Scanner sc = new Scanner(System.in);
		System.out.println("Moi ban nhap vao so a: ");
		int a = sc.nextInt(); // nhập một số từ bàn phím
		System.out.println("Moi ban nhap vao so b: ");
		int b = sc.nextInt(); // nhập một số từ bàn phím
		System.out.println("Moi ban nhap vao so c: ");
		int c = sc.nextInt(); // nhập một số từ bàn phím
		ArrayList<Integer> list = new ArrayList<Integer>(); // tạo list chứa 3 số vừa nhập
		list.add(a);
		list.add(b);
		list.add(c);
		int countLe = 0;
		int countChan = 0;
		for (Integer integer : list) { // duyệt list
			if (integer % 2 == 0) {
				countChan++;
			} else {
				countLe++;
			}
		}
		System.out.println("Tong so chan la: " + countChan);
		System.out.println("Tong so le la: " + countLe);
	}

// bài 7
	public static void bai7() {
		ArrayList<CanBo> list = new ArrayList<CanBo>();
		// khai báo 3 cán bộ
		CanBo cbA = new CanBo("Chuyen bay", 1976, true);
		CanBo cbB = new CanBo("Giai cuu", 1986, false);
		CanBo cbC = new CanBo("VN Airlines", 1979, true);
		list.add(cbA);
		list.add(cbB);
		list.add(cbC);
		int treNhat = cbA.tinhTuoi();
		String canBoTreNhat = cbA.getTen();
		boolean gioiTinhCboTre = cbA.isGioiTinh();
		for (CanBo canBo : list) {
			if(canBo.tinhTuoi()<treNhat && canBo.isGioiTinh() == true) {
				treNhat = canBo.tinhTuoi();
				canBoTreNhat = canBo.getTen();
				gioiTinhCboTre = canBo.isGioiTinh();
			}
		}
		System.out.println("Can bo tre nhat la: "+ canBoTreNhat);
		System.out.println("Tuoi: "+ treNhat);
		System.out.println("Gioi tinh: "+gioiTinhCboTre);
	}

// bài 8
	public static void bai8() {
		// khai báo tọa độ trường đại học
		ToaDo truongDH = new ToaDo(50, 80);
		// khai báo tên và tọa độ 3 sinh viên
		SinhVien svA = new SinhVien("Sinh Vien A", new ToaDo(25, 50));
		SinhVien svB = new SinhVien("Sinh Vien B", new ToaDo(15, 30));
		SinhVien svC = new SinhVien("Sinh Vien C", new ToaDo(45, 10));
		float khoangCachXaNhat = svA.getToaDoSV().khoangCach(truongDH);
		SinhVien sinhVienXaNhat = svA;
		ArrayList<SinhVien> list = new ArrayList<SinhVien>();
		list.add(svA);
		list.add(svB);
		list.add(svC);
		for (SinhVien sinhVien : list) {
			if (sinhVien.getToaDoSV().khoangCach(truongDH) > khoangCachXaNhat) {
				khoangCachXaNhat = sinhVien.getToaDoSV().khoangCach(truongDH);
				sinhVienXaNhat = sinhVien;
			}
		}
		System.out.println("Sinh vien xa truong nhat la: " + sinhVienXaNhat.getTenSV());
		System.out.println("Khoang cach la: " + khoangCachXaNhat);

	}

	public static void main(String[] args) {
		bai6();
	}
}
