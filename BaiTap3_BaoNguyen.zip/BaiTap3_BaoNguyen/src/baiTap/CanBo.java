package baiTap;

import java.time.LocalDate;

public class CanBo {
	private String ten;
	private int namSinh;
	private boolean gioiTinh;

	public CanBo() {
		super();
	}

	public CanBo(String ten, int namSinh, boolean gioiTinh) {
		super();
		this.ten = ten;
		this.namSinh = namSinh;
		this.gioiTinh = gioiTinh;
	}

	public String getTen() {
		return ten;
	}

	public void setTen(String ten) {
		this.ten = ten;
	}

	public int getNamSinh() {
		return namSinh;
	}

	public void setNamSinh(int namSinh) {
		this.namSinh = namSinh;
	}

	public boolean isGioiTinh() {
		return gioiTinh;
	}

	public void setGioiTinh(boolean gioiTinh) {
		this.gioiTinh = gioiTinh;
	}

	public int tinhTuoi() {
		int tuoi = LocalDate.now().getYear() - this.namSinh;
		return tuoi;
	}
}
