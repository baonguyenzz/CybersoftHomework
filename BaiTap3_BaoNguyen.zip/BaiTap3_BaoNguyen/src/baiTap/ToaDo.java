package baiTap;

public class ToaDo {
	private float x;
	private float y;

	public ToaDo() {
		super();
	}

	public ToaDo(float x, float y) {
		super();
		this.x = x;
		this.y = y;
	}

	public float getX() {
		return x;
	}

	public void setX(float x) {
		this.x = x;
	}

	public float getY() {
		return y;
	}

	public void setY(float y) {
		this.y = y;
	}

	public float khoangCach(ToaDo tdo) {
		float dx = this.x - tdo.x;
		float dy = this.y - tdo.y;
		return (float) Math.sqrt(dx * dx + dy * dy);
	}
}
