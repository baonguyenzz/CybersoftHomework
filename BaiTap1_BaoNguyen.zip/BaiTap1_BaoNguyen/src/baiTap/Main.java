package baiTap;

import java.util.Scanner;
import java.util.Arrays;

public class Main {
// bài 1
	public static void bai1() {
		// cho người dùng nhập 2 số từ bàn phím
		Scanner sc = new Scanner(System.in);
		System.out.println("Moi nhap so a: ");
		int a = sc.nextInt();
		System.out.println("Moi nhap so b: ");
		int b = sc.nextInt();
		sc.close();
		int max = a > b ? a : b; // gán max cho số lớn nhất
		System.out.println("So lon nhat giua a va b la: " + max);
	}

// bài 2
	public static void bai2() {
		Scanner sc = new Scanner(System.in);
		// khai báo mảng 1 chiều 3 phần tử
		int a[] = new int[3];
		// nhập giá trị cho từng phần tử trong mảng
		System.out.println("Moi ban nhap 3 so bat ky: ");
		for (int i = 0; i < 3; i++) {
			a[i] = sc.nextInt();
		}
		// xuất ra màn hình mảng ban đầu
		System.out.println("danh sach cac phan tu cua mang: ");
		for (int i = 0; i < a.length; i++) {
			System.out.println(a[i]);
		}
		int temp;
		// dùng hoán vị để sắp xếp tăng dần
		for (int i = 0; i < a.length; i++) {
			for (int j = i + 1; j <= 2; j++) {
				if (a[i] > a[j]) {
					temp = a[i];
					a[i] = a[j];
					a[j] = temp;
				}
			}
		}
//	Arrays.sort(a); cách khác
		System.out.println("3 so tang dan la: ");
		for (int i = 0; i < 3; i++) {
			System.out.println(a[i]);
		}
	}

//bài 3
// tạo hàm đảo ngược thứ tự phần tử mảng
	public static int[] reverseArray(int[] a, int n) {
		int[] Narray = new int[n];

		int j = n;

		for (int i = 0; i < n; i++) {

			Narray[j - 1] = a[i];

			j = j - 1;

		}
		return Narray;
	}

	public static void bai3() {
		Scanner sc = new Scanner(System.in);
		// khai báo mảng 1 chiều 3 phần tử
		int a[] = new int[3];
		// nhập giá trị cho từng phần tử trong mảng
		System.out.println("Moi ban nhap 3 so bat ky: ");
		for (int i = 0; i < a.length; i++) {
			a[i] = sc.nextInt();
		}
		// xuất ra màn hình mảng ban đầu
		System.out.println("danh sach cac phan tu cua mang: ");
		for (int i = 0; i < a.length; i++) {
			System.out.println(a[i]);
		}
		// hỏi người dùng chọn sắp xếp theo thứ tự nào
		do {
			sc.nextLine(); // xử lý trôi lệnh
			System.out.println("Ban muon tang or giam ?");
			String chon = sc.nextLine();
			if (chon.equalsIgnoreCase("tang") || chon.equalsIgnoreCase("giam")) {
				if (chon.equalsIgnoreCase("tang")) {
					Arrays.sort(a);
					System.out.println("Mang tang dan: ");
					for (int num : a) {
						System.out.println(num);
					}
				} else {
					Arrays.sort(a);
					int[] Narray = reverseArray(a, a.length);
					System.out.println("Mang giam dan: ");
					for (int num : Narray) {
						System.out.println(num);
					}
				}
			} else {
				System.out.println("Chi duoc type tang or giam, moi nhap lai");
			}
		} while (true);
	}
//bai 4
	public static void bai4() {
		 Scanner sc = new Scanner(System.in);

	        int number;

	        do {
	            System.out.print("Nhap vao so nguyen co 2 chu so: ");
	            number = sc.nextInt();
	        } while (Math.abs(number) < 10 || Math.abs(number) > 99);
	        // khai báo 2 mảng chứa cách đọc hàng chục và hàng đơn vị
	        String[] chuc = {"", "muoi", "hai muoi", "ba muoi", "bon muoi", "nam muoi", "sau muoi", "bay muoi", "tam muoi", "chin muoi"};
	        String[] donvi = {"", "mot", "hai", "ba", "bon", "nam", "sau", "bay", "tam", "chin"};
	        int sochuc = Math.abs(number) / 10;
	        int sodonvi = Math.abs(number) % 10;
	        System.out.print("Cach doc cua so " + number + " la: ");

	        if (number < 0) {
	            System.out.print("am ");
	        }
	        System.out.print(chuc[sochuc]);
            if (sodonvi != 0) {
                System.out.print(" " + donvi[sodonvi]);
            } else {
        	System.out.print(donvi[sodonvi]);
        }

        sc.close();
	}
//bai 5
	public static void bai5() {
		do {
		Scanner sc = new Scanner(System.in);
		System.out.println("Ai dang su dung may ?");
		String user = sc.nextLine();
		switch(user) {
		case "B":
			System.out.println("Chao hop ly de thuong Bo!");
			break;
		case "H":
			System.out.println("Chao hop ly de thuong Me!");
			break;
		case "A":
			System.out.println("Chao hop ly de thuong Anh!");
			break;
		case "E":
			System.out.println("Chao hop ly de thuong Em!");
			break;
		default:
			System.out.println("Co la ai ? Chau ko biet! Co di ra di!");
		}
		} while(true);
	}
	public static void main(String[] args) {
		bai5();
	}
}
